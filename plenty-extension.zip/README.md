# plenty-extension
Extension to help local bookshops.
